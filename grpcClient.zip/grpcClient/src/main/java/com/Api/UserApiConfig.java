package com.Api;

import io.dropwizard.Configuration;

public class UserApiConfig extends Configuration {

}
